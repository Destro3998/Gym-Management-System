import sys

line_1 = sys.stdin.readline()

for line_1 in range(1,100):
  line_2 = sys.stdin.readline()
  if 1 <= len(line_2) <= 50:
      print(line_2)


